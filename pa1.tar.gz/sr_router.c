/**********************************************************************
 * file:  sr_router.c
 * date:  Mon Feb 18 12:50:42 PST 2002
 * Contact: casado@stanford.edu
 *
 * Description:
 *
 * This file contains all the functions that interact directly
 * with the routing table, as well as the main entry method
 * for routing.
 *
 **********************************************************************/

#include <stdio.h>
#include <assert.h>

/* Added the following library */
#include <stdlib.h>
#include <string.h>
/* ----- */

#include "sr_if.h"
#include "sr_rt.h"
#include "sr_router.h"
#include "sr_protocol.h"
#include "sr_arpcache.h"
#include "sr_utils.h"

/*---------------------------------------------------------------------
 * Method: sr_init(void)
 * Scope:  Global
 *
 * Initialize the routing subsystem
 *
 *---------------------------------------------------------------------*/

void sr_init(struct sr_instance* sr)
{
    /* REQUIRES */
    assert(sr);

    /* Initialize cache and cache cleanup thread */
    sr_arpcache_init(&(sr->cache));

    pthread_attr_init(&(sr->attr));
    pthread_attr_setdetachstate(&(sr->attr), PTHREAD_CREATE_JOINABLE);
    pthread_attr_setscope(&(sr->attr), PTHREAD_SCOPE_SYSTEM);
    pthread_attr_setscope(&(sr->attr), PTHREAD_SCOPE_SYSTEM);
    pthread_t thread;

    pthread_create(&thread, &(sr->attr), sr_arpcache_timeout, sr);
    
    /* Add initialization code here! */


} /* -- sr_init -- */

/*---------------------------------------------------------------------
 * Method: sr_find_if_with_addr(uint8_t *addr)
 * Scope:  Global
 *
 * This method searches through the if_list to find the interface
 * correspond to the input MAC address, null if nothing is found.
 *---------------------------------------------------------------------*/
struct sr_if* sr_find_if_with_addr(struct sr_instance *sr,
	uint8_t *addr) {
	struct sr_if *if_walker = sr->if_list;
	while (if_walker) {
		if (!memcmp(if_walker->addr, addr, ETHER_ADDR_LEN)) {
			return if_walker;
		}
		if_walker = if_walker->next;
	}

	return NULL;
}



/*---------------------------------------------------------------------
 * Method: sr_send_icmp_error(struct sr_instance *sr, uint8_t *packet, int type, int code, struct sr_if *src_if)
 * Scope:  Global
 *
 * This method send a constructed ICMP packet to the sender of the input packet
 * that has the message of unreachable target depending on the input code. The packet will be send through the
 * interface indicated in the parameter, if intf is NULL, then the message is sent through the interface
 * to the sender of packet.
 *---------------------------------------------------------------------*/
void sr_send_icmp_error(struct sr_instance *sr,
	uint8_t *packet, 
	int type,
	int code,
	struct sr_if *src_if) {
	int rep_packet_size = sizeof(sr_ethernet_hdr_t) + sizeof(sr_ip_hdr_t) + sizeof(sr_icmp_t3_hdr_t);
	uint8_t *rep_packet = (uint8_t *)malloc(rep_packet_size);
	sr_ethernet_hdr_t *rep_packet_eth_hdr = (sr_ethernet_hdr_t *)rep_packet;
	sr_ip_hdr_t *rep_packet_ip_hdr = (sr_ip_hdr_t *)(rep_packet + sizeof(sr_ethernet_hdr_t));
	sr_icmp_t3_hdr_t *rep_packet_icmp_hdr = (sr_icmp_t3_hdr_t *)(rep_packet + sizeof(sr_ethernet_hdr_t) + sizeof(sr_ip_hdr_t));
	sr_ip_hdr_t *ip_hdr = (sr_ip_hdr_t *)(packet + sizeof(sr_ethernet_hdr_t));


	/* Construct ICMP header and content*/
	rep_packet_icmp_hdr->icmp_type = type;
	rep_packet_icmp_hdr->icmp_code = code;
	rep_packet_icmp_hdr->icmp_sum = 0;
	rep_packet_icmp_hdr->unused = 0;
	rep_packet_icmp_hdr->next_mtu = 0;
	memcpy(rep_packet_icmp_hdr->data, ip_hdr, sizeof(sr_ip_hdr_t) + 8);
	rep_packet_icmp_hdr->icmp_sum = cksum(rep_packet_icmp_hdr, sizeof(sr_icmp_t3_hdr_t));

	/* Construct the IP header */
	memcpy(rep_packet_eth_hdr, packet, sizeof(sr_ethernet_hdr_t));
	struct sr_if *sender_if = sr_find_if_with_addr(sr, rep_packet_eth_hdr->ether_dhost);
	struct sr_if *ent_if;
	if (src_if) {
		ent_if = src_if;
	}
	else {
		ent_if = sender_if;
	}
	

	memcpy(rep_packet_ip_hdr, ip_hdr, sizeof(sr_ip_hdr_t));
	rep_packet_ip_hdr->ip_dst = rep_packet_ip_hdr->ip_src;
	rep_packet_ip_hdr->ip_src = ent_if->ip;
	rep_packet_ip_hdr->ip_p = ip_protocol_icmp;
	rep_packet_ip_hdr->ip_id = 0;
	rep_packet_ip_hdr->ip_len = htons(sizeof(sr_icmp_t3_hdr_t) + sizeof(sr_ip_hdr_t));
	rep_packet_ip_hdr->ip_sum = 0;
	rep_packet_ip_hdr->ip_sum = cksum(rep_packet_ip_hdr, sizeof(sr_ip_hdr_t));

	/* Construct the Ethernet header */
	memcpy(rep_packet_eth_hdr->ether_dhost, rep_packet_eth_hdr->ether_shost, ETHER_ADDR_LEN);
	memcpy(rep_packet_eth_hdr->ether_shost, sender_if->addr, ETHER_ADDR_LEN);

	sr_send_packet(sr, rep_packet, rep_packet_size, sender_if->name);

	free(rep_packet);
}


/*---------------------------------------------------------------------
 * Method: sr_forward_packet(struct sr_instance *sr, uint8_t *packet, unsigned int len, char *iface)
 * Scope:  Global
 *
 * This method forwards the input packet through the input interface after
 * modify the TTL and recalculate checksum. Note that it is assumed the
 * packet is correct in checksum when received and has the minimum length.
 * The original packet will be not modified. This will also deal with
 * the error of time out if TTL is 0
 *---------------------------------------------------------------------*/
void sr_forward_packet(struct sr_instance *sr, 
	uint8_t *packet, 
	unsigned int len, 
	char *iface) {
	sr_ip_hdr_t *ip_hdr = (sr_ip_hdr_t *)(packet + sizeof(sr_ethernet_hdr_t));
	if (ip_hdr->ip_ttl == 1) {
		sr_send_icmp_error(sr, packet, 11, 0, NULL);
	}
	else {
		uint8_t *mod_packet = malloc(len);
		memcpy(mod_packet, packet, len);
		sr_ethernet_hdr_t *mod_eth_hdr = (sr_ethernet_hdr_t *)mod_packet;
		struct sr_if *sender_if = sr_get_interface(sr, iface);
		memcpy(mod_eth_hdr->ether_shost, sender_if->addr, ETHER_ADDR_LEN);
		struct sr_arpentry *ip_mac_entry = sr_arpcache_lookup(&(sr->cache), ip_hdr->ip_dst);
		memcpy(mod_eth_hdr->ether_dhost, ip_mac_entry->mac, ETHER_ADDR_LEN);
		sr_ip_hdr_t *mod_ip_hdr = (sr_ip_hdr_t *)(mod_packet + sizeof(sr_ethernet_hdr_t));
		mod_ip_hdr->ip_ttl--;
		mod_ip_hdr->ip_sum = 0;
		mod_ip_hdr->ip_sum = cksum(mod_ip_hdr, sizeof(sr_ip_hdr_t));
		sr_send_packet(sr, mod_packet, len, iface);

		free(ip_mac_entry);
		free(mod_packet);
	}

}

/*---------------------------------------------------------------------
 * Method: sr_process_arp_reply(struct sr_instance* sr, uint8_t *packet)
 * Scope:  Global
 *
 * This method process the ARP reply for this router and forward all packets
 * in the queue.
 *---------------------------------------------------------------------*/
void sr_process_arp_reply(struct sr_instance* sr, uint8_t *packet) {
	sr_arp_hdr_t *arp_hdr = (sr_arp_hdr_t *)(packet + sizeof(sr_ethernet_hdr_t));
	struct sr_arpreq *req = sr_arpcache_insert(&(sr->cache), arp_hdr->ar_sha, arp_hdr->ar_sip);

	if (req) {
		struct sr_packet *pk_walker = req->packets;
		while (pk_walker) {
			sr_forward_packet(sr, pk_walker->buf, pk_walker->len, pk_walker->iface);
			pk_walker = pk_walker->next;
		}
		sr_arpreq_destroy(&(sr->cache), req);
	}
}



/*---------------------------------------------------------------------
 * Method: sr_send_arp_reply(struct sr_instance *sr, uint8_t *packet)
 * Scope:  Global
 *
 * This method send an ARP reply packet to the sender of the input packet
 * that tells the sender the MAC address of the router.
 *---------------------------------------------------------------------*/
void sr_send_arp_reply(struct sr_instance *sr, uint8_t *packet) {
	uint8_t *rep_packet = (uint8_t *)malloc(sizeof(sr_ethernet_hdr_t) + sizeof(sr_arp_hdr_t));
	sr_ethernet_hdr_t *rep_packet_eth_hdr = (sr_ethernet_hdr_t *)rep_packet;
	sr_arp_hdr_t *rep_packet_arp_hdr = (sr_arp_hdr_t *)(rep_packet + sizeof(sr_ethernet_hdr_t));
	sr_arp_hdr_t *arp_hdr = (sr_arp_hdr_t *)(packet + sizeof(sr_ethernet_hdr_t));
	/* Copy general info about the packet */
	memcpy(rep_packet_arp_hdr, arp_hdr, sizeof(sr_arp_hdr_t));
	rep_packet_arp_hdr->ar_op = htons(arp_op_reply);
	memcpy(rep_packet_arp_hdr->ar_tha, arp_hdr->ar_sha, ETHER_ADDR_LEN);
	rep_packet_arp_hdr->ar_tip = arp_hdr->ar_sip;
	/* Get the MAC address of the IP address */
	struct sr_if *if_walker = sr->if_list;
	while (if_walker) {
		if (if_walker->ip == arp_hdr->ar_tip) {
			break;
		}
		if_walker = if_walker->next;
	}
	/* Modify the reply packet last time and send it */
	memcpy(rep_packet_eth_hdr->ether_dhost, arp_hdr->ar_sha, ETHER_ADDR_LEN);
	memcpy(rep_packet_eth_hdr->ether_shost, if_walker->addr, ETHER_ADDR_LEN);
	rep_packet_eth_hdr->ether_type = htons(ethertype_arp);
	rep_packet_arp_hdr->ar_sip = arp_hdr->ar_tip;
	memcpy(rep_packet_arp_hdr->ar_sha, if_walker->addr, ETHER_ADDR_LEN);

	sr_send_packet(sr, rep_packet, sizeof(sr_ethernet_hdr_t) + sizeof(sr_arp_hdr_t), if_walker->name);
	/* We don't need the packet after sending it*/
	free(rep_packet);
}

/*---------------------------------------------------------------------
 * Method: sr_send_echo_reply(struct sr_instance *sr, uint8_t *packet, unsigned int len)
 * Scope:  Global
 *
 * This method send an ICMP echo reply packet to the sender of the input packet.
 *---------------------------------------------------------------------*/
void sr_send_echo_reply(struct sr_instance *sr, uint8_t *packet, unsigned int len) {
	/* Formulate a reply */
	uint8_t *rep_packet = (uint8_t *)malloc(len);
	sr_ethernet_hdr_t *rep_packet_eth_hdr = (sr_ethernet_hdr_t *)rep_packet;
	sr_ip_hdr_t *rep_packet_ip_hdr = (sr_ip_hdr_t *)(rep_packet + sizeof(sr_ethernet_hdr_t));
	sr_icmp_hdr_t *rep_packet_icmp_hdr = (sr_icmp_hdr_t *)(rep_packet + sizeof(sr_ethernet_hdr_t) + sizeof(sr_ip_hdr_t));
	memcpy(rep_packet, packet, len);
	/* Modify ICMP header, set type and code to correspond with echo reply and compute checksum */
	rep_packet_icmp_hdr->icmp_type = 0;
	rep_packet_icmp_hdr->icmp_code = 0;
	rep_packet_icmp_hdr->icmp_sum = 0;
	rep_packet_icmp_hdr->icmp_sum = cksum(rep_packet_icmp_hdr, len - sizeof(sr_ethernet_hdr_t) - sizeof(sr_ip_hdr_t));
	/* Modify IP header, swap source and destination address and recompute checksum */
	uint32_t temp = rep_packet_ip_hdr->ip_dst;
	rep_packet_ip_hdr->ip_dst = rep_packet_ip_hdr->ip_src;
	rep_packet_ip_hdr->ip_src = temp;
	rep_packet_ip_hdr->ip_sum = 0;
	rep_packet_ip_hdr->ip_sum = cksum(rep_packet_ip_hdr, sizeof(sr_ip_hdr_t));
	/* Modify Ethernet header, change MAC address for source and destination */
	/* Find the interface in which the packet came in */
	struct sr_if *ent_if = sr_find_if_with_addr(sr, rep_packet_eth_hdr->ether_dhost);

	memcpy(rep_packet_eth_hdr->ether_dhost, rep_packet_eth_hdr->ether_shost, ETHER_ADDR_LEN);
	memcpy(rep_packet_eth_hdr->ether_shost, ent_if->addr, ETHER_ADDR_LEN);



	sr_send_packet(sr, rep_packet, len, ent_if->name);

	free(rep_packet);
}
/*---------------------------------------------------------------------
 * Method: ip_prefix_comp(uint32_t ip1, uint32_t ip2)
 * Scope:  Global
 *
 * This method compares the input two ips and return how many bytes are the same
 * for the prefixes. Note that rt_ip should alreay have mask applied. Returns
 * the number of bytes that are the same for the prefix.
 *---------------------------------------------------------------------*/
int ip_prefix_comp(uint32_t rt_ip, uint32_t packet_ip) {
	uint32_t comp_mask = 0xff;
	int i;
	int result = 0;
	for (i = 3; i >= 0; i--) {
		if (((rt_ip >> i * 8) & comp_mask) == ((packet_ip >> i * 8) & comp_mask)) {
			result++;
		}
		else {
			break;
		}

	}
	return result;
}

/*---------------------------------------------------------------------
 * Method: sr_LPM(struct sr_instance *sr, uint32_t ip_dst)
 * Scope:  Global
 *
 * This method performs longest prefix match for the input IP with the
 * routing table stored in sr. Returns the entry in the routing table
 * if a match is found, otherwise NULL. Note that the input ip should
 * be in network byte order.
 *---------------------------------------------------------------------*/
struct sr_rt* sr_LPM(struct sr_instance *sr,
	uint32_t ip_dst) {
	struct sr_rt *rt_walker = sr->routing_table;
	struct sr_rt *best_match = NULL;
	int best_match_record = 0;
	uint32_t rt_ip, packet_ip;
	while (rt_walker) {
		rt_ip = ntohl(rt_walker->dest.s_addr & rt_walker->mask.s_addr);
		packet_ip = ntohl(ip_dst);
		int cur_score = ip_prefix_comp(rt_ip, packet_ip);
		if (cur_score > best_match_record) {
			best_match_record = cur_score;
			best_match = rt_walker;
		}
		rt_walker = rt_walker->next;
	}

	return best_match;
}


/*---------------------------------------------------------------------
 * Method: sr_send_arp_request(struct sr_instance *sr, struct sr_arpreq *req)
 * Scope:  Global
 *
 * This method generates an ARP request packet for the input ARP request and 
 * send it through the corresponding interface.
 *---------------------------------------------------------------------*/
void sr_send_arp_request(struct sr_instance *sr,
	struct sr_arpreq *req) {
	uint8_t *arp_req = malloc(sizeof(sr_ethernet_hdr_t) + sizeof(sr_arp_hdr_t));
	sr_ethernet_hdr_t *arp_req_eth_hdr = (sr_ethernet_hdr_t *)arp_req;
	sr_arp_hdr_t *arp_req_arp_hdr = (sr_arp_hdr_t *)(arp_req + sizeof(sr_ethernet_hdr_t));
	uint32_t dst_ip = req->ip;
	struct sr_if *intf = sr_get_interface(sr, req->packets->iface);

	/* Filling in the ethernet header */
	uint8_t broadcast_addr[ETHER_ADDR_LEN] = { 0 };
	int i;
	for (i = 0; i < ETHER_ADDR_LEN; i++) {
		broadcast_addr[i] = 0xff;
	}
	memcpy(arp_req_eth_hdr->ether_dhost, &broadcast_addr, ETHER_ADDR_LEN);
	memcpy(arp_req_eth_hdr->ether_shost, intf->addr, ETHER_ADDR_LEN);
	arp_req_eth_hdr->ether_type = htons(ethertype_arp);

	/* Filling in the ARP header */
	uint8_t broadcast_addr2[ETHER_ADDR_LEN] = { 0 };
	arp_req_arp_hdr->ar_hrd = htons(arp_hrd_ethernet);
	arp_req_arp_hdr->ar_pro = htons(ethertype_ip);
	arp_req_arp_hdr->ar_hln = ETHER_ADDR_LEN;
	arp_req_arp_hdr->ar_pln = 4; /* IP addresses are 4 bytes long */
	arp_req_arp_hdr->ar_op = htons(arp_op_request);
	memcpy(arp_req_arp_hdr->ar_sha, intf->addr, ETHER_ADDR_LEN);
	arp_req_arp_hdr->ar_sip = intf->ip;
	memcpy(arp_req_arp_hdr->ar_tha, &broadcast_addr2, ETHER_ADDR_LEN);
	arp_req_arp_hdr->ar_tip = dst_ip;

	sr_send_packet(sr, arp_req, sizeof(sr_ethernet_hdr_t) + sizeof(sr_arp_hdr_t), intf->name);

	free(arp_req);

}
/*---------------------------------------------------------------------
 * Method: handle_arpreq(struct sr_instance *sr, struct sr_arpreq *req)
 * Scope:  Global
 *
 * This method handles ARP request that are SENT BY the router to another
 * host. Return True if an request was destroyed, False otherwise.
 *---------------------------------------------------------------------*/
int handle_arpreq(struct sr_instance *sr, struct sr_arpreq *req) {
	/* Get the current time and compared with the sent time of the request */
	/* If one second has passed, we start process */
	time_t now;
	time(&now);
	if (difftime(now, req->sent) >= 1.0) {
		if (req->times_sent >= 5) {
			/* If we have already sent 5 request and no response, send the senders of all packets in this request ICMP host unreachable */
			struct sr_packet *pk_walker = req->packets;
			while (pk_walker) {
				sr_send_icmp_error(sr, pk_walker->buf, 3, 1, sr_get_interface(sr, req->packets->iface));
				pk_walker = pk_walker->next;
			}
			sr_arpreq_destroy(&(sr->cache), req);
			return 1;
		}
		else {
			/* Otherwise we send the request */
			sr_send_arp_request(sr, req);
			req->sent = time(0);
			req->times_sent++;

		}
	}

	return 0;
}

/*---------------------------------------------------------------------
 * Method: sanity_check_packet(uint8_t *packet, unsigned int len)
 * Scope:  Global
 *
 * This method return true if the IP packet has correct length and checksum,
 * false otherwise.
 *---------------------------------------------------------------------*/
int sanity_check_packet(uint8_t *packet, unsigned int len) {
	/* Check the length */
	if (len < sizeof(sr_ethernet_hdr_t) + sizeof(sr_ip_hdr_t)) {
		printf("Error: Length of packet is less than minimum length of IP packet. \n");
		return 0;
	}
	/* Check checksum */
	sr_ip_hdr_t *ip_hdr = (sr_ip_hdr_t *)(packet + sizeof(sr_ethernet_hdr_t));
	/* We are calculating checksum at destination, so when we calculate checksum we have to set the checksum field to 0, make a copy */
	sr_ip_hdr_t *ip_hdr_copy = (sr_ip_hdr_t *)malloc(sizeof(sr_ip_hdr_t));
	memcpy(ip_hdr_copy, ip_hdr, sizeof(sr_ip_hdr_t));
	ip_hdr_copy->ip_sum = 0;
	if (cksum(ip_hdr_copy, sizeof(sr_ip_hdr_t)) != ip_hdr->ip_sum) {
		printf("Error: Checksum is not correct. \n");
		return 0;
	}
	free(ip_hdr_copy);
	return 1;
}

/*---------------------------------------------------------------------
 * Method: sr_handlepacket(uint8_t* p,char* interface)
 * Scope:  Global
 *
 * This method is called each time the router receives a packet on the
 * interface.  The packet buffer, the packet length and the receiving
 * interface are passed in as parameters. The packet is complete with
 * ethernet headers.
 *
 * Note: Both the packet buffer and the character's memory are handled
 * by sr_vns_comm.c that means do NOT delete either.  Make a copy of the
 * packet instead if you intend to keep it around beyond the scope of
 * the method call.
 *
 *---------------------------------------------------------------------*/

void sr_handlepacket(struct sr_instance* sr,
        uint8_t * packet/* lent */,
        unsigned int len,
        char* interface/* lent */)
{
  /* REQUIRES */
  assert(sr);
  assert(packet);
  assert(interface);

  printf("*** -> Received packet of length %d \n",len);

  /* fill in code here */
  if (ethertype(packet) == ethertype_arp) {
	  printf("Got an arp packet \n");
	  /* Check the type of the ARP packet*/
	  sr_arp_hdr_t *arp_hdr = (sr_arp_hdr_t *)(packet + sizeof(sr_ethernet_hdr_t));
	  if (ntohs(arp_hdr->ar_op) == arp_op_request) {
		  printf("Got an arp request \n");
		  /* We then construct a reply and send it back*/
		  sr_send_arp_reply(sr, packet);
		

	  }
	  else if (ntohs(arp_hdr->ar_op) == arp_op_reply) {
		  printf("Got an arp reply \n");
		  sr_process_arp_reply(sr, packet);
	  }
	  else {
		  /* Should never be here */
		  printf("Error: opcode for ARP packet unrecognized.\n");
	  }
  }
  else if (ethertype(packet) == ethertype_ip) {
	  printf("Got an ip packet \n");
	  /* Sanity check the packet, see if the minimum length and checksum is correct */
	
	  /* In case that the packet is not correct, drop it???? */

	  if (sanity_check_packet(packet, len)) {
		  /* Check if this packet is for one of the router's interface */
		  sr_ip_hdr_t *ip_hdr = (sr_ip_hdr_t *)(packet + sizeof(sr_ethernet_hdr_t));
		  struct sr_if *if_walker = sr->if_list;
		  while (if_walker) {
			  if (if_walker->ip == ip_hdr->ip_dst) {
				  break;
			  }
			  if_walker = if_walker->next;
		  }
		  /* If yes, we formulate an reply */
		  if (if_walker) {

			  /* If the protocol is ICMP echo, then we send an reply */
			  if (ip_hdr->ip_p == ip_protocol_icmp) {

				  sr_icmp_hdr_t *icmp_hdr = (sr_icmp_hdr_t *)(packet + sizeof(sr_ethernet_hdr_t) + sizeof(sr_ip_hdr_t));
				  /* TODO: need to set a constant for the echo request code */
				  if (icmp_hdr->icmp_type == 8) {
					  sr_send_echo_reply(sr, packet, len);
				  }

			  }
			  /* Otherwise if it's TCP or UDP we send ICMP port unreachable */
			  else {
				  sr_send_icmp_error(sr, packet, 3, 3, NULL);

			  }

		  }
		  /* Otherwise */
		  else {
			  /* Check routing table, use LPM to find a matching destination */
			  struct sr_rt *best_match = sr_LPM(sr, ip_hdr->ip_dst);

			  /* If we do find a match*/
			  if (best_match) {
				  /* Check ARP cache see if we can find the IP to MAC mapping */
				  struct sr_arpentry *entry = sr_arpcache_lookup(&(sr->cache), ip_hdr->ip_dst);
				  if (entry) {
					  /* Send frame to next hop */
					  sr_forward_packet(sr, packet, len, best_match->interface);
					  free(entry);
				  }
				  /* If not we must send ARP request */
				  else {
					  /* Create an ARP request and send it */
					  struct sr_arpreq *req = sr_arpcache_queuereq(&(sr->cache), ip_hdr->ip_dst, packet, len, best_match->interface);
					  handle_arpreq(sr, req);
					  
				  }
			  }
			  /* If we can't find one, send ICMP net unreachable */
			  else {
				  sr_send_icmp_error(sr, packet, 3, 0, NULL);
			  }
		  }
	  }
	  
	  
  }
  else {
	  printf("Error: unrecognized type of packet. \n");
  }


}/* end sr_ForwardPacket */
